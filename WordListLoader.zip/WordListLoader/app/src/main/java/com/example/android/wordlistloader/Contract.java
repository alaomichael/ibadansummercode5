package com.example.android.wordlistloader;

import android.net.Uri;
import android.provider.BaseColumns;

public	final	class	Contract {
    // To	prevent	the	Contract class from	being instantiated,	add	a private, empty constructor.
    // This	is a standard pattern for classes that are used	to	hold meta information and constants	for	an app.
    private Contract() {
    }

    private static final String TAG = Contract.class.getSimpleName();



    public static final int ALL_ITEMS = -2;
    public static final String COUNT = "count";

    public static final String AUTHORITY =
            "com.example.android.wordlistsqlwithcontentprovider.provider";
    public	static	final	String	CONTENT_PATH	=	"words";
    public	static	final Uri CONTENT_URI	=
            Uri.parse("content://"	+	AUTHORITY	+	"/"	+	CONTENT_PATH);
    public	static	final	Uri	ROW_COUNT_URI	=
            Uri.parse("content://"	+	AUTHORITY	+	"/"	+	CONTENT_PATH	+	"/"	+	COUNT);

    // Declare	MIME	types	for	single	and	multiple	record	responses:
    static final String SINGLE_RECORD_MIME_TYPE =
            "vnd.android.cursor.item/vnd.com.example.provider.words";
    static final String MULTIPLE_RECORDS_MIME_TYPE =
            "vnd.android.cursor.dir/vnd.com.example.provider.words";


    /*
     * Constants for the database are moved out of WordListOpenHelper into the contract.
     * A common way to organize a contract class is to put definitions that are global to your
     * database in the root level of the class. Then create an inner class for each table
     * that enumerates its columns.
     */

    public static final String DATABASE_NAME = "wordlist";

    /**
     * Inner class that defines the table contents
     * <p>
     * By implementing the BaseColumns interface, your inner class can inherit a primary
     * key field called _ID that some Android classes such as cursor adaptors will expect it to
     * have. It's not required, but this can help your database work harmoniously with the
     * Android framework.
     */
    public static abstract class WordList implements BaseColumns {

        // Table
        public static final String WORD_LIST_TABLE = "word_entries";

        // Column names
        public static final String KEY_ID = "_id";
        public static final String KEY_WORD = "word";
    }
}