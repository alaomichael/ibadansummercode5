package com.example.android.wordlistloader;

/**
 * Data model for one word list item.
 */
public class WordListItem {

    private int mId;
    private String mWord;

    public WordListItem() {}

    public int getId() {
        return this.mId;
    }

    public String getWord() {
        return this.mWord;
    }

    public void setId(int id) {
        this.mId = id;
    }

    public void setWord(String word) {
        this.mWord = word;
    }
}