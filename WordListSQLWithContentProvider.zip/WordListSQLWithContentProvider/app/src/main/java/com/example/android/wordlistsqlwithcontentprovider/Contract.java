package com.example.android.wordlistsqlwithcontentprovider;

import android.net.Uri;
import android.provider.BaseColumns;

public	final	class	Contract {
    // To	prevent	the	Contract class from	being instantiated,	add	a private, empty constructor.
    // This	is a standard pattern for classes that are used	to	hold meta information and constants	for	an app.
    private Contract() {
    }
// Declare	the	URI	scheme	for content	provider.
    public	static	final	String	DATABASE_NAME	=	"wordlist";

    public	static	final	int	ALL_ITEMS	=	-2;
    public	static	final	String	COUNT	=	"count";

    public static final String AUTHORITY =
            "com.example.android.wordlistsqlwithcontentprovider.provider";

    // Only one public table.
    public static final String CONTENT_PATH = "words";

    // Content URI for this table. Returns all items.
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" + CONTENT_PATH);

    // URI to get the number of entries.
    public static final Uri ROW_COUNT_URI =
            Uri.parse("content://" + AUTHORITY + "/" + CONTENT_PATH + "/" + COUNT);

    static final String SINGLE_RECORD_MIME_TYPE =
            "vnd.android.cursor.item/vnd.com.example.provider.words";
    static final String MULTIPLE_RECORDS_MIME_TYPE =
            "vnd.android.cursor.dir/vnd.com.example.provider.words";


    // Static inner class
    public	static	abstract	class	WordList	implements BaseColumns {
    // Table name
        public static final String WORD_LIST_TABLE = "word_entries";

    // Column names...
    public static final String KEY_ID = "_id";
    public static final String KEY_WORD = "word";
    }
}